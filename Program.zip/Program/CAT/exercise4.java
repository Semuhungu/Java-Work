class Employee{  
 int id;  
 String name;  
}  
class TestEmployee1{  
 
  Employee s1=new Employee();  
  System.out.println(s1.id);  
  System.out.println(s1.name);  
 }  
 